package com.example.soundnaam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoundNaamApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoundNaamApplication.class, args);
		System.out.println("SoundNaam");
	}

}
