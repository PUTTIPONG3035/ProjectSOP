package com.example.soundnaam.POJO;

import java.util.ArrayList;

public class Users {
    public static ArrayList<User> users;
}
