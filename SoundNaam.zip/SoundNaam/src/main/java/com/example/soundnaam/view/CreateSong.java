package com.example.soundnaam.view;

import com.example.soundnaam.POJO.Music;
import com.example.soundnaam.POJO.Song;
import com.example.soundnaam.POJO.User;
import com.example.soundnaam.service.AudioRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.FileBuffer;
import com.vaadin.flow.router.Route;
import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

@Route("createSong")
public class CreateSong extends VerticalLayout {
    private AudioRepository audioRepository;
    private String audioId, imageId;
    private Text audioFile, coverFile;
    private TextField titile, album;
    private TextArea description, lyrics;
    private Button submit;
    private Upload uploadAudio, uploadCover;
    private H1 textmain;



    @Autowired
    public CreateSong(AudioRepository audioRepository) {
        this.audioRepository = audioRepository;

        textmain = new H1("Upload Audio");
        titile = new TextField("Title");
        titile.setWidth("30%");
        titile.getStyle().set("--vaadin-input-field-border-width", "1px");

        description = new TextArea("Description");
        description.setWidth("30%");
        description.getStyle().set("--vaadin-input-field-border-width", "1px");

        lyrics = new TextArea("Lyrics");
        lyrics.setWidth("30%");
        lyrics.getStyle().set("--vaadin-input-field-border-width", "1px");

        album = new TextField("Album");
        album.setWidth("30%");
        album.getStyle().set("--vaadin-input-field-border-width", "1px");

        submit = new Button("Upload New Song");
        submit.getStyle().set("background-color", "#FFA62B");

        audioFile = new Text("Audio");
        coverFile = new Text("Cover Image");


        // Set up the Upload component with FileBuffer as the receiver
        uploadAudio = new Upload(new FileBuffer());
        uploadAudio.setAcceptedFileTypes("audio/*");
        uploadAudio.addSucceededListener(event -> {
            InputStream inputStream = ((FileBuffer) uploadAudio.getReceiver()).getInputStream();
            saveAudioToMongoDB(event.getFileName(), event.getMIMEType(), inputStream);
        });
        uploadAudio.setWidth("30%");

        uploadCover = new Upload(new FileBuffer());
        uploadCover.setAcceptedFileTypes("image/jpeg", "image/png", "image/gif");
        uploadCover.addSucceededListener(event -> {
            InputStream inputStream = ((FileBuffer) uploadCover.getReceiver()).getInputStream();
            saveAudioToMongoDB(event.getFileName(), event.getMIMEType(), inputStream);
        });
        uploadCover.setWidth("30%");

        submit.addClickListener(event -> {
            System.out.println("submit");
            String key = "token";
            UI.getCurrent().getPage().executeJs("return localStorage.getItem($0)", key)
                    .then(String.class, this::fetchUserData);

//            new Notification(output, 10000).open();
        });








        add(textmain, titile, description, lyrics, album, audioFile, uploadAudio, coverFile, uploadCover, submit);
        this.setAlignItems(Alignment.CENTER);

    }





    private void fetchUserData(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);

        if(token == null){
            UI.getCurrent().navigate(MainView.class);
        }

        try {
            String jsonResponse = WebClient.builder()
                    .baseUrl("http://localhost:8080")
                    .defaultHeaders(header -> header.addAll(headers))
                    .build()
                    .get()
                    .uri("/me")
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println("JSON Response: " + jsonResponse);


            ObjectMapper objectMapper = new ObjectMapper();

            // Convert JSON string to User object using Jackson
            User user = objectMapper.readValue(jsonResponse, User.class);

            // Store the username in a class variable



            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());
            System.out.println(imageId);

            Song data = new Song(null, titile.getValue(), lyrics.getValue(), "Artist", audioId, imageId, String.valueOf(new Date()), album.getValue(), 0, 0, 0, user.getEmail(), user.getUsername());


            Boolean output = WebClient.create()
                    .post()
                    .uri("http://localhost:8080/addSong")
                    .bodyValue(data)
                    .retrieve().bodyToMono(Boolean.class).block();

            System.out.println(output);






        } catch (Exception e) {
            // Handle the exception appropriately
            System.err.println("Error fetching user data: " + e.getMessage());
        }
    }



    private void saveAudioToMongoDB(String fileName, String mimeType, InputStream inputStream) {
        byte[] data = new byte[0];
        try {
            data = IOUtils.toByteArray(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Music media = new Music();
        // Set other metadata fields
        media.setData(data);
        media.setFileName(fileName);
        media.setMimeType(mimeType);

        audioRepository.save(media);
        System.out.println(media.getId());
        if (media.getMimeType().equals("audio/mpeg")){
            this.audioId = media.getId();
        }else{
            this.imageId = media.getId();
        }
    }
}
