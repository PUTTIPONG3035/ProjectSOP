package com.example.soundnaam.view;

import com.example.soundnaam.POJO.Playlist;
import com.example.soundnaam.POJO.User;
import com.example.soundnaam.service.AudioRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Date;
@Route(value = "CreatePlaylist")
public class CreatePlaylist extends VerticalLayout {
    private TextField name;
    private Button submit;
    private RadioButtonGroup<String> status;

    @Autowired
    public CreatePlaylist(){
        name = new TextField("Name");
        submit = new Button("New Playlist");
        status = new RadioButtonGroup<>("Status", "Private", "Public");

        submit.addClickListener(event -> {
            System.out.println("submit");
            String key = "token";
            UI.getCurrent().getPage().executeJs("return localStorage.getItem($0)", key)
                    .then(String.class, this::fetchUserData);

//            new Notification(output, 10000).open();
        });
        add(name, status, submit);

    }

    private void fetchUserData(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);

        if(token == null){
            UI.getCurrent().navigate(MainView.class);
        }

        try {
            String jsonResponse = WebClient.builder()
                    .baseUrl("http://localhost:8080")
                    .defaultHeaders(header -> header.addAll(headers))
                    .build()
                    .get()
                    .uri("/me")
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println("JSON Response: " + jsonResponse);


            ObjectMapper objectMapper = new ObjectMapper();

            // Convert JSON string to User object using Jackson
            User user = objectMapper.readValue(jsonResponse, User.class);

            // Store the username in a class variable

            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());

            Playlist data = new Playlist(user.getEmail(), user.getUsername(), name.getValue(), status.getValue());

            Boolean output = WebClient.create()
                    .post()
                    .uri("http://localhost:8080/addPlaylist")
                    .bodyValue(data)
                    .retrieve().bodyToMono(Boolean.class).block();

            System.out.println(output);

        } catch (Exception e) {
            // Handle the exception appropriately
            System.err.println("Error fetching user data: " + e.getMessage());
        }
    }

}