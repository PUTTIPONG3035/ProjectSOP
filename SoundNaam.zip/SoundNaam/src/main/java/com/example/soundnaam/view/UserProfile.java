package com.example.soundnaam.view;

import com.example.soundnaam.POJO.Playlist;
import com.example.soundnaam.POJO.Song;
import com.example.soundnaam.POJO.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.TabSheet;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.StreamResource;
import org.bson.types.Binary;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Route("UserProfile")
public class UserProfile extends Div {
    private H1 name;
    private Image profileImage;
    private Image profileImg;
    private Div playlist, subsription, redeem;
    private List<Playlist> playlists;
    private List<Song> songs;

    public UserProfile() {
        playlists = new ArrayList<>();
        songs = new ArrayList<>();
        createUI();
    }

    private void createUI() {


        Div mainContainer = new Div();
        mainContainer.getStyle().set("display", "flex");
        mainContainer.getStyle().set("height", "100vh");
        mainContainer.getStyle().set("flex", "1");// 100% of the viewport height


        Div leftSection = new Div();
        Image logoImage = new Image("/images/Logo.png", "Logo");
        Button logout = new Button("LogOut");

        logout.getStyle().set("width", "200px");
        logoImage.getStyle().set("width" ,"300px").set("height", "150px");


        Div logo = new Div();

        logo.getStyle().set("text-align", "center");

        logo.add(logoImage, logout);
        leftSection.getStyle().set("background-color", "#5F9DB2");
        leftSection.getStyle().set("flex", "1");
        leftSection.getStyle().set("height", "100%"); // 1/3 of the height
        leftSection.getStyle().set("width", "5%");

        leftSection.add(logo);
        Div rightSection = new Div();

        rightSection.getStyle().set("background-color", "white");
        rightSection.getStyle().set("flex", "3");
        rightSection.getStyle().set("height", "100%");

        Div searchBar = new Div();
        searchBar.getStyle().set("display" , "flex");
        TextField search = new TextField();
        profileImage = new Image();
        search.getStyle().set("margin", "50px").set("width", "800px");
        profileImage.getStyle().set("width", "50px").set("height", "50px").set("border-radius", "50px").set("margin-top", "50px");


        searchBar.add(search, profileImage);


        Div profileBar = new Div();
        profileBar.getStyle().set("display", "flex");

        profileImg = new Image();
        profileImg.getStyle().set("width", "200px").set("height", "200px").set("border-radius", "50%").set("margin" , "20px");
        Div nameBar = new Div();
        name = new H1();

        H6 text = new H6("playList 6");

        nameBar.add(name, text);


        profileBar.add(profileImg, nameBar);
        profileBar.getStyle().set("alignItems", "center");

        playlist = new Div();
        subsription = new Div();
        redeem = new Div();
        TabSheet tabSheet = new TabSheet();
        tabSheet.add("Playlist", playlist);
        tabSheet.add("Subsription", subsription);
        tabSheet.add("Redeem", redeem);
        tabSheet.setWidthFull();


        rightSection.add(searchBar, profileBar, tabSheet);
        mainContainer.add(leftSection,rightSection);

        // Add the main container to the view
        add(mainContainer);
        loadPage();


        logout.addClickListener(event ->{
            logout();
        });

    }


    private void loadPage() {
        String key = "token";
        UI.getCurrent().getPage().executeJs("return localStorage.getItem($0)", key)
                .then(String.class, this::fetchUserData);
    }

    private void fetchUserData(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);

        if(token == null){
            UI.getCurrent().navigate(MainView.class);
        }
        try {
            String jsonResponse = WebClient.builder()
                    .baseUrl("http://localhost:8080")
                    .defaultHeaders(header -> header.addAll(headers))
                    .build()
                    .get()
                    .uri("/me")
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println("JSON Response: " + jsonResponse);


            ObjectMapper objectMapper = new ObjectMapper();

            // Convert JSON string to User object using Jackson
            User user = objectMapper.readValue(jsonResponse, User.class);

            // Store the username in a class variable


            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());



            name.setText(user.getUsername());

            myPlaylist(user.getEmail());
            System.out.println(user.getImage().length());

            if(user.getImage().length() == 24) {



                WebClient.Builder webClientBuilder = WebClient.builder()
                        .exchangeStrategies(ExchangeStrategies.builder()
                                .codecs(configurer -> configurer.defaultCodecs()
                                        .maxInMemorySize(10 * 1024 * 1024)) // Set the buffer limit to 5 MB
                                .build());

                byte[] dataImage = webClientBuilder.build()
                        .get()
                        .uri("http://localhost:8080/getAudioSong/" + user.getImage())
                        .accept(MediaType.APPLICATION_OCTET_STREAM)
                        .retrieve()
                        .bodyToMono(byte[].class)
                        .block();

                StreamResource resource = new StreamResource("image.jpg", () -> new ByteArrayInputStream(dataImage));

                System.out.println("User : " + resource);

                profileImage.setSrc(resource);
                profileImg.setSrc(resource);
            }
            else{
                profileImage.setSrc(user.getImage());
                profileImg.setSrc(user.getImage());
            }
        } catch (Exception e) {
            // Handle the exception appropriately
            System.err.println("Error fetching user data: " + e.getMessage());
        }
    }

    private void logout() {
        // Remove token from localStorage
        UI.getCurrent().getPage().executeJs("localStorage.removeItem($0)", "token");

        // Redirect to the login page or perform other logout actions
        UI.getCurrent().navigate(MainView.class);
    }

    private void myPlaylist(String email){
        this.playlists = WebClient.create()
                .get()
                .uri("http://localhost:8080/getPlaylistByEmail/" + email)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<Playlist>>() {})
                .block();
        System.out.println("-------------------------------------------MY playlists-------------------------------------------------------------------");
        System.out.println(this.playlists);


        VerticalLayout veri = new VerticalLayout();

        if (playlists != null && !playlists.isEmpty()) {
            HorizontalLayout allSongs = new HorizontalLayout();
            for (Playlist myPlaylist : playlists) {


                H4 myTitle = new H4(myPlaylist.getPlaylistName());
                Text myStatus = new Text((myPlaylist.getStatus()));

                VerticalLayout veriSongs = new VerticalLayout();
                veriSongs.add( myTitle, myStatus);
                allSongs.add(veriSongs);
            }

            playlist.add(allSongs);
            playlist.setSizeFull();
        }
        else {
            playlist.removeAll();
            playlist.add(new Text("No data"));
        }

        System.out.println("===========================================================================");
        System.out.println("PLAYLIST"+playlist);
    }


}