package com.example.soundnaam.view;

import com.example.soundnaam.POJO.Playlist;
import com.example.soundnaam.POJO.Song;
import com.example.soundnaam.POJO.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.TabSheet;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.StreamResource;
import org.bson.types.Binary;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Route("UserProfile")
public class UserProfile extends Div {
    private H1 name;
    private Image profileImage;
    private Image profileImg;
    private Div playlist, subsription, redeem;
    private List<Playlist> playlists;
    private List<Song> songs;

    public UserProfile() {
        playlists = new ArrayList<>();
        songs = new ArrayList<>();
        createUI();
    }

    private void createUI() {

        // Create main container
        Div mainContainer = new Div();
        mainContainer.getStyle().set("display", "flex");

        mainContainer.getStyle().set("height", "100vh");

        mainContainer.getStyle().set("flex", "1");// 100% of the viewport height

        // Create orange background on the left (1/3 of the height)

        Div leftSection = new Div();
        Image logoImage = new Image("/images/Logo.png", "Logo");
        Button logout = new Button("LogOut");

        logout.getStyle().set("width", "200px");
        logoImage.getStyle().set("width" ,"300px").set("height", "150px");


        Div logo = new Div();

        logo.getStyle().set("text-align", "center");

        logo.add(logoImage, logout);
        leftSection.getStyle().set("background-color", "#5F9DB2");
        leftSection.getStyle().set("flex", "1");
        leftSection.getStyle().set("height", "100%"); // 1/3 of the height
        leftSection.getStyle().set("width", "5%");

        leftSection.add(logo);

        Div rightSection = new Div();

        rightSection.getStyle().set("background-color", "white");
        rightSection.getStyle().set("flex", "3");
        rightSection.getStyle().set("height", "100%");


        Div searchBar = new Div();

        searchBar.getStyle().set("display" , "flex");
        TextField search = new TextField();
        profileImage = new Image();
        search.getStyle().set("margin", "50px").set("width", "800px");
        profileImage.getStyle().set("width", "50px").set("height", "50px").set("border-radius", "50px").set("margin-top", "50px");


        searchBar.add(search, profileImage);


        Div profileBar = new Div();
        profileBar.getStyle().set("display", "flex");

        profileImg = new Image();
        profileImg.getStyle().set("width", "200px").set("height", "200px").set("border-radius", "50%").set("margin" , "20px");
        Div nameBar = new Div();
        name = new H1();

        H6 text = new H6("playList 6");

        nameBar.add(name, text);
//        nameBar.getStyle().set("margin-top","70px").set("background-color", "pink");

        profileBar.add(profileImg, nameBar);
        profileBar.getStyle().set("alignItems", "center");

        playlist = new Div();
        subsription = new Div();
        redeem = new Div();
        TabSheet tabSheet = new TabSheet();
        tabSheet.add("Playlist", playlist);
        tabSheet.add("Subsription", subsription);
        tabSheet.add("Redeem", redeem);
        tabSheet.setWidthFull();


//        MemoryBuffer buffer = new MemoryBuffer();
//        Upload upload = new Upload(buffer);
//        upload.setAcceptedFileTypes("image/jpeg", "image/png");
//
//        Button uploadButton = new Button("Upload Image");
//
//        // Create a FormLayout to arrange components
//        FormLayout formLayout = new FormLayout();
//        formLayout.add(upload, uploadButton);

        // Handle the file upload
//        upload.addSucceededListener(event -> {
//            try {
//                Binary imageData = new Binary(buffer.getInputStream().readAllBytes());
//                System.out.println(imageData);
//
//                byte[] imageDataBytes = imageData.getData();
//
//                String hexString = bytesToHex(imageDataBytes);
//
//                // Create data URI
//                String dataUri = "data:image/jpeg;base64," + hexString;
//
//                // Print the data URI
//                System.out.println(dataUri);
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }
//            // Save the image data to MongoDB
//            // Your logic to save imageData to MongoDB goes here
//
//            // Update the profile image
//            profileImg.setSrc(new StreamResource("filename", () -> {
//                try {
//
//                    return new ByteArrayInputStream(buffer.getInputStream().readAllBytes());
//                } catch (IOException e) {
//                    throw new RuntimeException(e);
//                }
//            }));
//
//
//        });
//
//        uploadButton.addClickListener(event -> {
//            // Your logic for additional actions on button click
//            try {
//                Binary imageData = new Binary(buffer.getInputStream().readAllBytes());
//                System.out.println(imageData);
//
//
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }
//        });


        rightSection.add(searchBar, profileBar, tabSheet);
//        myPlaylist();


        // Create login form on the right (2/3 of the height)
//        FormLayout loginForm = new FormLayout();
//        H1 header = new H1("Log in");
//
//        RouterLink forgot = new RouterLink("Forgot Password", ForgotPage.class);
//        header.getStyle().set("text-align", "center");
//        TextField usernameField = new TextField("Username");
//        PasswordField passwordField = new PasswordField("Password");
//        Button loginButton = new Button("Login", event -> {
//            Notification.show("Login button clicked");
//        });
//
//        loginForm.add(header, usernameField, passwordField, loginButton, forgot);
//        forgot.getStyle().set("text-align", "center").set("margin-top", "20px");
//        loginForm.getStyle().set("flex", "4");
//        loginForm.getStyle().set("width", "600px");
//        HorizontalLayout horizontalLayout = new HorizontalLayout();
//        horizontalLayout.add(loginForm);
//
//        horizontalLayout.getStyle().set("margin", "200px");

        // Add sections to the main container
        mainContainer.add(leftSection,rightSection);

        // Add the main container to the view
        add(mainContainer);
        loadPage();


        logout.addClickListener(event ->{
            logout();
        });

    }
//    private static String bytesToHex(byte[] bytes) {
//        StringBuilder hexStringBuilder = new StringBuilder(2 * bytes.length);
//        for (byte b : bytes) {
//            hexStringBuilder.append(String.format("%02x", b));
//        }
//        return hexStringBuilder.toString();
//    }



    private void loadPage() {
        String key = "token";
        UI.getCurrent().getPage().executeJs("return localStorage.getItem($0)", key)
                .then(String.class, this::fetchUserData);
    }

    private void fetchUserData(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);

        if(token == null){
            UI.getCurrent().navigate(MainView.class);
        }
        try {
            String jsonResponse = WebClient.builder()
                    .baseUrl("http://localhost:8080")
                    .defaultHeaders(header -> header.addAll(headers))
                    .build()
                    .get()
                    .uri("/me")
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println("JSON Response: " + jsonResponse);


            ObjectMapper objectMapper = new ObjectMapper();

            // Convert JSON string to User object using Jackson
            User user = objectMapper.readValue(jsonResponse, User.class);

            // Store the username in a class variable


            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());



            name.setText(user.getUsername());

            myPlaylist(user.getEmail());

            WebClient.Builder webClientBuilder = WebClient.builder()
                    .exchangeStrategies(ExchangeStrategies.builder()
                            .codecs(configurer -> configurer.defaultCodecs()
                                    .maxInMemorySize(10 * 1024 * 1024)) // Set the buffer limit to 5 MB
                            .build());

            byte[] dataImage = webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8080/getAudioSong/" + user.getImage())
                    .accept(MediaType.APPLICATION_OCTET_STREAM)
                    .retrieve()
                    .bodyToMono(byte[].class)
                    .block();

            StreamResource resource = new StreamResource("image.jpg", () -> new ByteArrayInputStream(dataImage));

            profileImage.setSrc(resource);
            profileImg.setSrc(resource);


        } catch (Exception e) {
            // Handle the exception appropriately
            System.err.println("Error fetching user data: " + e.getMessage());
        }
    }

    private void logout() {
        // Remove token from localStorage
        UI.getCurrent().getPage().executeJs("localStorage.removeItem($0)", "token");

        // Redirect to the login page or perform other logout actions
        UI.getCurrent().navigate(MainView.class);
    }

    private void myPlaylist(String email){
        this.playlists = WebClient.create()
                .get()
                .uri("http://localhost:8080/getPlaylistByEmail/" + email)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<Playlist>>() {})
                .block();
        System.out.println("-------------------------------------------MY playlists-------------------------------------------------------------------");
        System.out.println(this.playlists);
//        this.songs = this.playlists.get(0).getSong();
//        System.out.println(this.songs);

        VerticalLayout veri = new VerticalLayout();
//        Image cover = new Image(songs.get(0).getImage(), "coverPlaylist");
//        cover.setWidth("100px");
//        H4 title = new H4(playlists.get(1).getPlaylistName());
//        Text status = new Text((playlists.get(1).getStatus()));
//        veri.add( title, status);

        if (playlists != null && !playlists.isEmpty()) {
            HorizontalLayout allSongs = new HorizontalLayout();
            for (Playlist myPlaylist : playlists) {
//                Image coverImage = new Image(myPlaylist.getCover(), "cover image");
//                coverImage.setWidth("100px");

                H4 myTitle = new H4(myPlaylist.getPlaylistName());
                Text myStatus = new Text((myPlaylist.getStatus()));

                VerticalLayout veriSongs = new VerticalLayout();
                veriSongs.add( myTitle, myStatus);
                allSongs.add(veriSongs);
            }

            playlist.add(allSongs);
            playlist.setSizeFull();
        }
        else {
            playlist.removeAll();
            playlist.add(new Text("No data"));
        }
//        this.add(playlist);
        System.out.println("===========================================================================");
        System.out.println("PLAYLIST"+playlist);
    }


}