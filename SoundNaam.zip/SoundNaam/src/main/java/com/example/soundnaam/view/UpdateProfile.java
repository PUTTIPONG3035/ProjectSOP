package com.example.soundnaam.view;

import com.example.soundnaam.POJO.Music;
import com.example.soundnaam.POJO.Song;
import com.example.soundnaam.POJO.User;
import com.example.soundnaam.service.AudioRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.FileBuffer;
import com.vaadin.flow.router.Route;
import org.apache.commons.compress.utils.IOUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Map;

@Route("updateProfile")
public class UpdateProfile extends VerticalLayout {
    private AudioRepository audioRepository;
    private TextField usernameFeild, emailFeild;
    private TextField passwordFeild;

    private Upload  uploadImage;

    private Button update;

    private String audioId, imageId;

   public UpdateProfile(AudioRepository audioRepository){
       this.audioRepository = audioRepository;

         usernameFeild = new TextField("Username");
         passwordFeild = new TextField("password");
         emailFeild = new TextField("email");
         uploadImage = new Upload();

         update = new Button("Update");


       uploadImage = new Upload(new FileBuffer());
       uploadImage.setAcceptedFileTypes("image/jpeg", "image/png", "image/gif");
       uploadImage.addSucceededListener(event -> {
           InputStream inputStream = ((FileBuffer) uploadImage.getReceiver()).getInputStream();
           saveAudioToMongoDB(event.getFileName(), event.getMIMEType(), inputStream);
       });
       uploadImage.setWidth("30%");
         add(emailFeild, usernameFeild, passwordFeild, uploadImage, update);

       loadPage();

       update.addClickListener(event -> {
           System.out.println("submit");
           String key = "token";
           UI.getCurrent().getPage().executeJs("return localStorage.getItem($0)", key)
                   .then(String.class, this::fetchUserData);

//            new Notification(output, 10000).open();
       });




   }

    private void fetchUserData(String token){
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);

        if(token == null){
            UI.getCurrent().navigate(MainView.class);
        }

        try {
            String jsonResponse = WebClient.builder()
                    .baseUrl("http://localhost:8080")
                    .defaultHeaders(header -> header.addAll(headers))
                    .build()
                    .get()
                    .uri("/me")
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println("JSON Response: " + jsonResponse);


            ObjectMapper objectMapper = new ObjectMapper();

            // Convert JSON string to User object using Jackson
            User user = objectMapper.readValue(jsonResponse, User.class);

            // Store the username in a class variable



            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());


            MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();

            String username = usernameFeild.getValue();
            String password = passwordFeild.getValue();
            String email = emailFeild.getValue();

            String image =imageId;

            formData.add("email", email);
            formData.add("password", password);
            formData.add("username", username);
            formData.add("image", image);

            Map<String, Object> userList = WebClient.create()
                    .post()
                    .uri("http://localhost:8080/updateUser")
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body(BodyInserters.fromFormData(formData))
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {
                    })
                    .block();

            System.out.println(userList);





//            User data = new User(user.getEmail(), password.getValue(), username.getValue(), imageId);


//            Boolean output = WebClient.create()
//                    .post()
//                    .uri("http://localhost:8080/update")
//                    .bodyValue(data)
//                    .retrieve().bodyToMono(Boolean.class).block();
//
//            System.out.println(output);






        } catch (Exception e) {
            // Handle the exception appropriately
            System.err.println("Error fetching user data: " + e.getMessage());
        }
    }



    private void saveAudioToMongoDB(String fileName, String mimeType, InputStream inputStream) {
        byte[] data = new byte[0];
        try {
            data = IOUtils.toByteArray(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Music media = new Music();
        // Set other metadata fields
        media.setData(data);
        media.setFileName(fileName);
        media.setMimeType(mimeType);

        audioRepository.save(media);
        System.out.println(media.getId());
        if (media.getMimeType().equals("audio/mpeg")){
            this.audioId = media.getId();
        }else{
            this.imageId = media.getId();
        }
    }


    private void loadPage(){

        String key = "token";
        UI.getCurrent().getPage().executeJs("return localStorage.getItem($0)", key)
                .then(String.class, this::loadData);

    }


    public void loadData(String token){
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);

        if(token == null){
            UI.getCurrent().navigate(MainView.class);
        }

        try {
            String jsonResponse = WebClient.builder()
                    .baseUrl("http://localhost:8080")
                    .defaultHeaders(header -> header.addAll(headers))
                    .build()
                    .get()
                    .uri("/me")
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println("JSON Response: " + jsonResponse);


            ObjectMapper objectMapper = new ObjectMapper();

            // Convert JSON string to User object using Jackson
            User user = objectMapper.readValue(jsonResponse, User.class);

            // Store the username in a class variable



            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());

            usernameFeild.setValue(user.getUsername());
            passwordFeild.setValue(user.getPassword());










        } catch (Exception e) {
            // Handle the exception appropriately
            System.err.println("Error fetching user data: " + e.getMessage());
        }
    }
}
