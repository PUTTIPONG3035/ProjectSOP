package com.example.soundnaam.view;

import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.Upload;

public class UpdateProfile extends VerticalLayout {
    private TextField username;
    private TextField password;

    private Upload  uploadImage;

   public UpdateProfile(){

         username = new TextField();
         password = new TextField();
         uploadImage = new Upload();


         add(username, password, uploadImage);



    }

}
