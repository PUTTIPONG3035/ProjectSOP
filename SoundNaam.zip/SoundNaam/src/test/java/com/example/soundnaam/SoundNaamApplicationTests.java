package com.example.soundnaam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoundNaamApplicationTests {

	@Test
	void contextLoads() {
	}

}
